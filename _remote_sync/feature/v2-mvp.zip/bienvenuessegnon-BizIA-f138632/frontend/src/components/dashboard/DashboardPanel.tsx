"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useState } from "react";
import { AppPageLayout } from "@/components/layout/AppPageLayout";
import { Alert } from "@/components/ui/Alert";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Spinner } from "@/components/ui/Spinner";
import { useCompany } from "@/contexts/CompanyContext";
import { api } from "@/services/api";
import type { AnalysisResult } from "@/types";
import { getApiErrorMessage, isNetworkError } from "@/utils/apiError";
import { IconTrending, QuickActionIconSvg, type QuickActionIcon } from "@/components/icons/Icons";
import { formatCurrency, formatPercent } from "@/utils/format";

const QUICK_ACTIONS: Array<{
  href: string;
  title: string;
  desc: string;
  icon: QuickActionIcon;
}> = [
  { href: "/produits", title: "Ajouter des produits", desc: "Saisie manuelle de votre catalogue", icon: "package" },
  { href: "/ventes", title: "Enregistrer des ventes", desc: "Suivez chaque transaction", icon: "coins" },
  { href: "/import", title: "Importer un fichier", desc: "Excel, CSV, PDF ou photo de votre tableau", icon: "upload" },
  { href: "/chat", title: "Parler à l'assistant", desc: "Questions sur votre activité", icon: "bot" },
];

function KpiCard({
  label,
  value,
  sub,
  accent,
}: {
  label: string;
  value: string;
  sub?: string;
  accent: string;
}) {
  return (
    <article className={`kpi-card kpi-card--${accent}`}>
      <div className="kpi-card__glow" aria-hidden="true" />
      <p className="kpi-card__label">{label}</p>
      <p className="kpi-card__value">{value}</p>
      {sub && <p className="kpi-card__sub">{sub}</p>}
    </article>
  );
}

export function DashboardPanel() {
  const { currentCompany } = useCompany();
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState(false);
  const [exportingPdf, setExportingPdf] = useState(false);
  const [apiOffline, setApiOffline] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  const kpiConfig = useMemo(
    () => [
      {
        key: "revenue" as const,
        label: "Chiffre d'affaires",
        accent: "blue",
        format: (v: number) => formatCurrency(v, currentCompany.currency || "FCFA"),
      },
      {
        key: "cost" as const,
        label: "Coûts",
        accent: "slate",
        format: (v: number) => formatCurrency(v, currentCompany.currency || "FCFA"),
      },
      {
        key: "profit" as const,
        label: "Bénéfice",
        accent: "teal",
        format: (v: number) => formatCurrency(v, currentCompany.currency || "FCFA"),
      },
      {
        key: "margin_pct" as const,
        label: "Marge",
        accent: "violet",
        format: (v: number) => formatPercent(v),
      },
      {
        key: "units_sold" as const,
        label: "Unités vendues",
        accent: "amber",
        format: (v: number) => String(v),
      },
      {
        key: "sales_count" as const,
        label: "Nombre de ventes",
        accent: "rose",
        format: (v: number) => String(v),
      },
    ],
    [currentCompany.currency]
  );

  const loadSummary = useCallback(async () => {
    setLoading(true);
    setActionError(null);
    try {
      const data = await api.summary();
      setResult(data.result);
      setApiOffline(false);
    } catch (err) {
      if (isNetworkError(err)) {
        setApiOffline(true);
        setResult(null);
      } else {
        setActionError(getApiErrorMessage(err));
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadSummary();
  }, [loadSummary, currentCompany.id]);

  async function handleRunAnalysis() {
    if (
      !window.confirm(
        `Lancer l'analyse sur les produits et ventes de ${currentCompany.name} ?`,
      )
    ) {
      return;
    }
    setAnalyzing(true);
    setActionError(null);
    try {
      const data = await api.runAnalysis();
      setResult(data.result);
      setApiOffline(false);
    } catch (err) {
      if (isNetworkError(err)) {
        setApiOffline(true);
      } else {
        setActionError(getApiErrorMessage(err));
      }
    } finally {
      setAnalyzing(false);
    }
  }

  async function handleDownloadPdf() {
    setExportingPdf(true);
    setActionError(null);
    try {
      await api.reports.download("pdf");
    } catch (err) {
      setActionError(getApiErrorMessage(err));
    } finally {
      setExportingPdf(false);
    }
  }

  const kpis = result?.kpis;
  const hasData = kpis && (kpis.sales_count > 0 || kpis.revenue > 0);

  return (
    <AppPageLayout
      className="dashboard"
      eyebrow={`Tableau de bord • ${currentCompany.name}`}
      title="Vue d'ensemble"
      description={`Indicateurs clés, alertes et analyses de performance pour ${currentCompany.name} (${currentCompany.category || "Commerce Général"}).`}
      actions={
        <>
          <Button onClick={handleRunAnalysis} loading={analyzing} disabled={analyzing || apiOffline}>
            Lancer l&apos;analyse
          </Button>
          <Button variant="secondary" onClick={loadSummary} disabled={loading}>
            Actualiser
          </Button>
          <Button
            variant="secondary"
            onClick={handleDownloadPdf}
            loading={exportingPdf}
            disabled={!hasData || exportingPdf}
          >
            Télécharger le bilan PDF
          </Button>
        </>
      }
    >
      {actionError && !apiOffline && (
        <Alert variant="warning" title="Analyse indisponible">
          {actionError}
        </Alert>
      )}

      {loading ? (
        <div className="dashboard-loading">
          <Spinner label="Chargement de vos indicateurs…" />
        </div>
      ) : (
        <>
          <div className="kpi-grid">
            {kpiConfig.map(({ key, label, accent, format }) => {
              const raw = kpis ? Number(kpis[key]) : undefined;
              const value = hasData && raw !== undefined ? format(raw) : "—";
              const sub =
                key === "profit" && hasData
                  ? (raw ?? 0) >= 0
                    ? "Performance positive"
                    : "À surveiller"
                  : undefined;
              return (
                <KpiCard
                  key={key}
                  label={label}
                  value={value}
                  sub={sub}
                  accent={accent}
                />
              );
            })}
          </div>

          {!hasData && (
            <div className="dashboard-empty">
              <div className="dashboard-empty__intro card card--glass">
                <div className="dashboard-empty__icon" aria-hidden="true">
                  <IconTrending size={48} />
                </div>
                <h2>{apiOffline ? "Connexion en cours" : `Prêt à analyser ${currentCompany.name}`}</h2>
                <p className="muted">
                  {apiOffline
                    ? "Nous n'arrivons pas à joindre BizIA pour le moment. Patientez un instant, puis actualisez cette page."
                    : `Ajoutez des produits et des ventes pour ${currentCompany.name}, puis lancez l'analyse pour remplir ce tableau de bord.`}
                </p>
                {!apiOffline && (
                  <Button onClick={handleRunAnalysis} loading={analyzing}>
                    Lancer la première analyse pour {currentCompany.name}
                  </Button>
                )}
              </div>

              <div className="quick-actions">
                <h3 className="quick-actions__title">Démarrage rapide</h3>
                <div className="quick-actions__grid">
                  {QUICK_ACTIONS.map((action) => (
                    <Link key={action.href} href={action.href} className="quick-action card card--glass">
                      <span className="quick-action__icon" aria-hidden="true">
                        <QuickActionIconSvg name={action.icon} />
                      </span>
                      <div>
                        <strong>{action.title}</strong>
                        <p className="muted">{action.desc}</p>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          )}

          {hasData && result && (
            <div className="dashboard-sections">
              {result.week_over_week && (
                <div className="card card--glass dashboard-panel">
                  <div className="dashboard-panel__head">
                    <h2>
                      Évolution du bénéfice ({result.week_over_week.window_days} jour
                      {result.week_over_week.window_days > 1 ? "s" : ""} / période)
                    </h2>
                    <Badge variant={result.week_over_week.delta >= 0 ? "low" : "high"}>
                      {result.week_over_week.delta >= 0 ? "Hausse" : "Baisse"}
                    </Badge>
                  </div>
                  <div className="wow-stats">
                    <div className="wow-stat">
                      <span className="wow-stat__label">Bénéfice actuel</span>
                      <span className="wow-stat__value">
                        {formatCurrency(result.week_over_week.current_window_profit)}
                      </span>
                    </div>
                    <div className="wow-stat">
                      <span className="wow-stat__label">Variation</span>
                      <span
                        className={`wow-stat__value ${result.week_over_week.delta >= 0 ? "text-success" : "text-error"}`}
                      >
                        {result.week_over_week.delta >= 0 ? "+" : ""}
                        {formatCurrency(result.week_over_week.delta)}
                        {result.week_over_week.delta_pct != null &&
                          ` (${formatPercent(result.week_over_week.delta_pct)})`}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              <div className="page-grid">
                <div className="card card--glass dashboard-panel">
                  <h2>Top ventes</h2>
                  {result.top_sold.length === 0 ? (
                    <p className="muted">Aucune donnée pour le moment.</p>
                  ) : (
                    <div className="table-wrap">
                      <table className="data-table">
                        <thead>
                          <tr>
                            <th>Produit</th>
                            <th>Unités</th>
                            <th>CA</th>
                          </tr>
                        </thead>
                        <tbody>
                          {result.top_sold.map((p) => (
                            <tr key={p.sku}>
                              <td>{p.name}</td>
                              <td>{p.units_sold}</td>
                              <td>{formatCurrency(p.revenue)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>

                <div className="card card--glass dashboard-panel">
                  <h2>Top rentabilité</h2>
                  {result.top_profit.length === 0 ? (
                    <p className="muted">Aucune donnée pour le moment.</p>
                  ) : (
                    <div className="table-wrap">
                      <table className="data-table">
                        <thead>
                          <tr>
                            <th>Produit</th>
                            <th>Bénéfice</th>
                            <th>CA</th>
                          </tr>
                        </thead>
                        <tbody>
                          {result.top_profit.map((p) => (
                            <tr key={p.sku}>
                              <td>{p.name}</td>
                              <td>{formatCurrency(p.profit)}</td>
                              <td>{formatCurrency(p.revenue)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </div>

              <div className="page-grid">
                <div className="card card--glass dashboard-panel">
                  <h2>Stocks faibles</h2>
                  {result.low_stock.length === 0 ? (
                    <p className="muted">Aucun stock critique détecté.</p>
                  ) : (
                    <ul className="stock-list">
                      {result.low_stock.map((item) => (
                        <li key={item.sku}>
                          <strong>{item.name}</strong>
                          <span className="muted">
                            {item.stock_quantity} restant · seuil {item.low_stock_threshold}
                          </span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>

              {result.trend.length > 0 && (
                <div className="card card--glass dashboard-panel">
                  <h2>Tendances du chiffre d&apos;affaires</h2>
                  <div className="trend-bars">
                    {result.trend.map((point) => {
                      const max = Math.max(...result.trend.map((t) => t.revenue), 1);
                      const pct = (point.revenue / max) * 100;
                      return (
                        <div key={point.period} className="trend-bar">
                          <div className="trend-bar__fill" style={{ height: `${pct}%` }} />
                          <span className="trend-bar__label">{point.period}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {result.anomalies.length > 0 && (
                <div className="card card--glass dashboard-panel">
                  <h2>Anomalies</h2>
                  <ul className="alert-list">
                    {result.anomalies.map((item) => (
                      <li key={`${item.type}-${item.period}`}>
                        <Badge variant={item.severity === "high" ? "high" : "medium"}>
                          {item.severity}
                        </Badge>
                        <div>
                          <strong>{item.period}</strong>
                          <p className="muted">{item.message}</p>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {(result.alerts.length > 0 || result.insights.length > 0) && (
                <div className="page-grid">
                  {result.alerts.length > 0 && (
                    <div className="card card--glass dashboard-panel">
                      <h2>Alertes</h2>
                      <ul className="alert-list">
                        {result.alerts.map((a) => (
                          <li key={a.code + a.title}>
                            <Badge variant={a.severity}>{a.severity}</Badge>
                            <div>
                              <strong>{a.title}</strong>
                              <p className="muted">{a.detail}</p>
                            </div>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {result.insights.length > 0 && (
                    <div className="card card--glass dashboard-panel">
                      <h2>Insights</h2>
                      <ul className="insight-list">
                        {result.insights.map((insight, i) => (
                          <li key={i}>{insight}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}

              {result.recommendations.length > 0 && (
                <div className="card card--glass dashboard-panel">
                  <h2>Recommandations</h2>
                  <ul className="recommendation-list">
                    {result.recommendations.map((rec, i) => (
                      <li key={i}>
                        <Badge variant={rec.priority}>{rec.priority}</Badge>
                        <div>
                          <strong>{rec.action}</strong>
                          <p className="muted">{rec.why}</p>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </>
      )}
    </AppPageLayout>
  );
}
