"""Utilitaires backend."""
